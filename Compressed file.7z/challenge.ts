async function sleep(ms: number) {
    return new Promise((resolve, reject) => {
        setTimeout(() => resolve(), ms)
    })
}

async function randomDelay() {
    const randomTime = Math.round(Math.random() * 1000)
    return sleep(randomTime)
}

class ShipmentSearchIndex {
    async updateShipment(id: string, shipmentData: any) {
        const startTime = new Date()
        await randomDelay()
        const endTime = new Date()
        console.log(`update ${id}@${
            startTime.toISOString()
            } finished@${
            endTime.toISOString()
            }`
        )

        return { startTime, endTime }
    }
}

// Implementation needed
interface ShipmentUpdateListenerInterface {
    receiveUpdate(id: string, shipmentData: any): void
}

export class ShipmentUpdate implements ShipmentUpdateListenerInterface {
    private queue: string[];
    constructor(private shipmentSearchIndex: ShipmentSearchIndex) {
        this.queue = [];
    }
    async receiveUpdate(id: string, shipmentData: any) {
        if (this.queue.includes(id)) {
            console.log('this update is already in queue');
            return;
        }
        this.queue.push(id);
        const response = await this.shipmentSearchIndex.updateShipment(id, shipmentData);
        this.queue = this.queue.filter(ids => ids !== id);
    }
}