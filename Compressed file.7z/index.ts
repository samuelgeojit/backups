import http from "http";
import express from "express";
import { RequestHandler, Dictionary } from "express-serve-static-core";
const { PORT = 3000 } = process.env;

class Index {
  indexController(request: any, response: any) {
    response.send("Hello")
  }
  
  constructor() {
    const router = express();
    const server = http.createServer(router);
    server.listen(PORT, () =>
      console.log(`Server is running http://localhost:${PORT}...`)
    );
    router.get("/", this.indexController);
  }
  

}
new Index();