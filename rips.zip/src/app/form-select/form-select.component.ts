import { Component, OnInit, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, ControlValueAccessor, FormControl } from '@angular/forms';
@Component({
  selector: 'app-form-select',
  templateUrl: './form-select.component.html',
  styleUrls: ['./form-select.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => FormSelectComponent),
      multi: true,
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => FormSelectComponent),
      multi: true,
    }
  ]
})
export class FormSelectComponent implements ControlValueAccessor, OnInit {
  private _selectValue: any = '';
  /**
  * The method set in registerOnChange, it is just a placeholder for a method that takes one parameter, 
  * We use it to emit changes back to the form 
  */
  private _onTouchedCallback: () => {};
  private _onChangeCallback: (_:any) => {};
  private validationError;

  private onChangeFunction = (_: any) => { };
  constructor() { }

  ngOnInit() {
  }
  /**
  * Write a new value to the element.
  */
  writeValue(value: any): void {
    if (value !== undefined) {
      this._selectValue = value;
    }
  }
  /**
  * Set the function to be called 
  * when the control receives a change event.
  */
  registerOnChange(fn: any): void {
    this.onChangeFunction = fn;
  }
  /**
  * Set the function to be called 
  * when the control receives a touch event.
  */
  registerOnTouched(fn: any): void {
    // Will be implemented later since it is out of scope of requirment
  }
  /** 
   * Returns null when valid else the validation object 
   */
  public validate(c: FormControl) {
    return (!this.validationError) ? null : {
      appFormSelectError: {
        errorMessage: this.validationError,
        valid: false,
      },
    };
  }
  private onChange(event) {
    this.onChangeFunction(this._selectValue);
  }

}
