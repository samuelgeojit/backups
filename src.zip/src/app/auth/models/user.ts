export class User {
    name: string;
    email: string;
    token: string;
    bio: string;
    image: string;
}
