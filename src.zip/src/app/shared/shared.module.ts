import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpModule } from '@angular/http';
import { SharedRoutingModule } from './shared-routing.module';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { ApiService } from './services/api.service';

@NgModule({
  imports: [
    CommonModule,
    SharedRoutingModule,
    HttpModule
  ],
  declarations: [NotFoundComponent],
  providers: [ApiService]
})
export class SharedModule { }
