import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { BehaviorSubject } from 'rxjs';
import { environment } from '../../../environments/environment.prod';

@Injectable({
  providedIn: 'root',
})
export class AppTitleService {
  public titleBehaviorSubject: BehaviorSubject<string>;
  public apptitle;

  constructor(private titleService: Title) {
    this.apptitle = titleService.getTitle();
    this.titleBehaviorSubject = new BehaviorSubject<string>(this.apptitle);
  }

  setTitle(title: string) {
    this.apptitle = (title === null) ? environment.appTitle : title;
    this.titleService.setTitle(this.apptitle);
    this.titleBehaviorSubject.next(this.apptitle);
  }
}
