import { Component } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { AppTitleService } from './core/services/app-title.service';

@Component({
  selector: 'pms-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'pms-web';

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private appTitleService: AppTitleService) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        let data = null;
        let route = this.activatedRoute;
        while (route) {
          data = route.data || data;
          route = route.firstChild;
        }
        this.appTitleService.setTitle(data._value.title);
      }
    });
  }
}
