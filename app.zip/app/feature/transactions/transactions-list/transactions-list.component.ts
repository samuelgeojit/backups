import { Component, OnInit, ViewChild } from '@angular/core';
import { TransactionsDataService } from '../shared/data-services/transactions-data.service';
import { Transaction } from '../shared/interfaces/transaction';

@Component({
  selector: 'pms-transactions-list',
  templateUrl: './transactions-list.component.html',
  styleUrls: ['./transactions-list.component.scss']
})
export class TransactionsListComponent implements OnInit {
  transactions: Transaction[];
  constructor(private transactionsDataService: TransactionsDataService) { }

  ngOnInit() {
    this.transactionsDataService.getAllTransactions().subscribe(
      (transactions) => {
        this.transactions = transactions;
      }
    );
  }

}
