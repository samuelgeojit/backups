import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TransactionsDataService } from '../shared/data-services/transactions-data.service';
import { Transaction } from '../shared/interfaces/transaction';
import { Observable } from 'rxjs';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'pms-transactions-create',
  templateUrl: './transactions-form.component.html',
  styleUrls: ['./transactions-form.component.scss']
})
export class TransactionsFormComponent implements OnInit {
  transactionForm: FormGroup;
  transaction: Transaction;
  isCreditTransaction: boolean;
  submitted = false;
  constructor(private activeRoute: ActivatedRoute, private transactionService: TransactionsDataService, private fb: FormBuilder) {
  }

  ngOnInit() {
    const routeParams = this.activeRoute.snapshot.params;
    console.log(this.activeRoute);
    if (routeParams.id !== undefined) {
      this.transactionService.getTransactionById(routeParams.id).subscribe(data => {
        console.log(data);
        this.transaction = data;
        this.createTransactionForm();
      });
    } else {
      this.transaction = {
        accountFrom: '',
        accountTo: '',
        amount: '',
        created_by: '',
        created_date: '',
        date: '',
        description: '',
        id: 0,
        last_modified_by: '',
        last_modified_date: '',
        reciptVovcherNo: '',
        transactionType: 'credit',
      };
      this.createTransactionForm();
    }

  }
  createTransactionForm() {
    this.isCreditTransaction = (this.transaction.transactionType === 'credit') ? true : false;
    this.transactionForm = this.fb.group({
      accountFrom: [this.transaction.accountFrom, Validators.required],
      accountTo: [this.transaction.accountTo, Validators.required],
      amount: [this.transaction.amount, Validators.required],
      created_by: [this.transaction.created_by, Validators.required],
      created_date: [this.transaction.created_date, Validators.required],
      date: [this.transaction.date, Validators.required],
      description: [this.transaction.description, Validators.required],
      id: [this.transaction.id, Validators.required],
      last_modified_by: [this.transaction.last_modified_by, Validators.required],
      last_modified_date: [this.transaction.last_modified_date, Validators.required],
      reciptVoucherNo: [this.transaction.reciptVovcherNo, Validators.required],
      transactionType: [this.transaction.transactionType, Validators.required]
    });
    this.transactionForm
      .controls.transactionType
      .valueChanges
      .subscribe(newValue => {
        if (newValue !== this.transactionForm.value.transactionType) {
          this.isCreditTransaction = (newValue === 'credit') ? true : false;
          this.transactionForm.controls.reciptVoucherNo.setValue('');
          this.transactionForm.controls.reciptVoucherNo.setValidators(Validators.required);
          this.transactionForm.controls.accountFrom.setValue('');
          this.transactionForm.controls.accountFrom.setValidators(Validators.required);
          this.transactionForm.controls.accountTo.setValue('');
          this.transactionForm.controls.accountTo.setValidators(Validators.required);
        }
      });

  }

  get f() { return this.transactionForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.transactionForm.invalid) {
      return;
    }

    console.log(this.activeRoute.snapshot.data.title === 'UPDATE TRANSACTIONS');
  }
  onReset() {
    this.submitted = false;
    this.transactionForm.reset();
  }

}
