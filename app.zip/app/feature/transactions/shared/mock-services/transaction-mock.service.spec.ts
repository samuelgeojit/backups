import { TestBed } from '@angular/core/testing';

import { TransactionMockService } from './transaction-mock.service';

describe('TransactionMockService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TransactionMockService = TestBed.get(TransactionMockService);
    expect(service).toBeTruthy();
  });
});
