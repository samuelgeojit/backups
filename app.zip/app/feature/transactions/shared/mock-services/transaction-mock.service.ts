import { Injectable } from '@angular/core';
import { HttpRequest, HttpResponse, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, mergeMap, materialize, dematerialize } from 'rxjs/operators';
import { Transaction } from '../interfaces/transaction';
import { transactionsMock } from './transaction-mock';

@Injectable()
export class TransactionMockService {
  private readonly API_URL = '/transactions/';
  private transactions: Transaction[] = transactionsMock;
  constructor() { }

  intercept(request: HttpRequest<Transaction>, next: HttpHandler): Observable<HttpEvent<Transaction>> {

    return of(null).pipe(mergeMap(() => {
      console.log(request);
      if (request.url.endsWith(this.API_URL) && request.method === 'POST') {
        if (request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
          const filteredTransaction = this.transactions.filter(transaction => {
            return transaction.id === request.body.id;
          });

          if (filteredTransaction.length > 0) {
            const body = filteredTransaction[0];
            return of(new HttpResponse({ status: 422, body: { message: 'Transaction Already exist' } }));
          } else {
            return of(new HttpResponse({ status: 200, body: { message: 'Transaction saved sucessfully' } }));
          }
        } else {
          return throwError({ error: { message: 'Unauthorised' } });
        }
      }

      if (request.url.endsWith(this.API_URL) && request.method === 'GET') {
        console.log('--- Serving Transaction List ---');
        // if (request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
        return of(new HttpResponse({ status: 200, body: this.transactions }));
        // } else {
        //   return throwError({ error: { message: 'Unauthorised' } });
        // }
      }

      if (request.url.match(`^${this.API_URL}[0-9]+`) && request.method === 'GET') {
        console.log('----Serving Transaction---');
        // if (request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
        const urlParts = request.url.split('/');
        const id = parseInt(urlParts[urlParts.length - 1], 10);
        const matchedTransaction = this.transactions.filter(transaction => transaction.id === id);
        if (matchedTransaction.length) {
          return of(new HttpResponse({ status: 200, body: matchedTransaction[0] }));
        } else {
          return of(new HttpResponse({ status: 404, statusText: 'Transaction Not Found' }));
        }
        // } else {
        // return throwError({ error: { message: 'Unauthorised' } });
        // }
      }

      return next.handle(request);

    }))
      .pipe(materialize())
      .pipe(delay(2500))
      .pipe(dematerialize());
  }
}
