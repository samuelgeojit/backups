import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransactionMockService } from './mock-services/transaction-mock.service';
import { TransactionsDataService } from './data-services/transactions-data.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

const transactionProviders = [];
transactionProviders.push(TransactionsDataService);
if (!environment.production) {
  transactionProviders.push({
    provide: HTTP_INTERCEPTORS,
    useClass: TransactionMockService,
    multi: true
  });
}

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: transactionProviders
})
export class TransactionsSharedModule { }
