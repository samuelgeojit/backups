export interface Transaction {
  accountFrom: string;
  accountTo: string;
  amount: string;
  created_by: string;
  created_date: string;
  date: string;
  description: string;
  id: number;
  last_modified_by: string;
  last_modified_date: string;
  reciptVovcherNo: string;
  transactionType: string;
}

