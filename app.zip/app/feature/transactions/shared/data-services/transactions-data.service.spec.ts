import { TestBed } from '@angular/core/testing';

import { TransactionsDataService } from './transactions-data.service';

describe('TransactionsDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TransactionsDataService = TestBed.get(TransactionsDataService);
    expect(service).toBeTruthy();
  });
});
