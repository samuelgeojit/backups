import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Transaction } from '../interfaces/transaction';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TransactionsDataService {
  private readonly API_URL = '/transactions/';
  dataChange: BehaviorSubject<Transaction[]> = new BehaviorSubject<Transaction[]>([]);
  constructor(private httpClient: HttpClient) { }

  getAllTransactions(): Observable<Transaction[]> {
    return this.httpClient.get<Transaction[]>(this.API_URL);
  }
  getTransactionById(transactionId): Observable<Transaction> {
    return this.httpClient.get<Transaction>(this.API_URL + transactionId);
  }
  createTransaction(transaction: Transaction): Observable<Transaction> {
    return this.httpClient.post<Transaction>(this.API_URL + transaction.id, transaction);
  }
  updateTransaction(transaction: Transaction): Observable<Transaction> {
    return this.httpClient.put<Transaction>(this.API_URL + transaction.id, transaction);
  }
  deleteTransaction(transaction: Transaction): Observable<Transaction> {
    return this.httpClient.delete<Transaction>(this.API_URL + transaction.id);
  }
}
