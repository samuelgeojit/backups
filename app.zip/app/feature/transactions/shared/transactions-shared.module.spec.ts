import { TransactionsSharedModule } from './transactions-shared.module';

describe('TransactionsSharedModule', () => {
  let transactionsSharedModule: TransactionsSharedModule;

  beforeEach(() => {
    transactionsSharedModule = new TransactionsSharedModule();
  });

  it('should create an instance', () => {
    expect(transactionsSharedModule).toBeTruthy();
  });
});
