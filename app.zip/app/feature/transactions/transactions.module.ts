import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransactionsComponent } from './transactions.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { TransactionsListComponent } from './transactions-list/transactions-list.component';
import { TransactionsFormComponent } from './transactions-form/transactions-form.component';
import { TransactionsSharedModule } from './shared/transactions-shared.module';
const routes: Routes = [{
  path: '',
  component: TransactionsComponent,
  data: {
    title: 'TRANSACTIONS'
  }
}, {
  path: 'create',
  component: TransactionsFormComponent,
  data: {
    title: 'CREATE TRANSACTIONS'
  }
}, {
  path: 'update/:id',
  component: TransactionsFormComponent,
  data: {
    title: 'UPDATE TRANSACTIONS'
  }
}];
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes),
    TransactionsSharedModule
  ],
  exports: [RouterModule],
  declarations: [TransactionsComponent, TransactionsListComponent, TransactionsFormComponent]
})
export class TransactionsModule { }
