import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pms-income-expense-chart',
  templateUrl: './income-expense-chart.component.html',
  styleUrls: ['./income-expense-chart.component.scss']
})
export class IncomeExpenseChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
