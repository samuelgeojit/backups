import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pms-latest-transactions',
  templateUrl: './latest-transactions.component.html',
  styleUrls: ['./latest-transactions.component.scss']
})
export class LatestTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
