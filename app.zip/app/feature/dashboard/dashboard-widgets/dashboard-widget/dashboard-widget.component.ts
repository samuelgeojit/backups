import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pms-dashboard-widget',
  templateUrl: './dashboard-widget.component.html',
  styleUrls: ['./dashboard-widget.component.scss']
})
export class DashboardWidgetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
