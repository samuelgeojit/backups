import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pms-dashboard-widgets',
  templateUrl: './dashboard-widgets.component.html',
  styleUrls: ['./dashboard-widgets.component.scss']
})
export class DashboardWidgetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
