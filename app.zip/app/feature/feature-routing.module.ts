import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageNotFoundComponent } from '../shared/page-not-found/page-not-found.component';

const routes: Routes = [{
  path: '',
  redirectTo: '/dashboard',
  pathMatch: 'full'
}, {
  path: 'dashboard',
  loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule),
  data: {
    title: 'DASHBOARD'
  }
}, {
  path: 'projects',
  loadChildren: () => import('./projects/projects.module').then(m => m.ProjectsModule),
  data: {
    title: 'PROJECTS'
  }
}, {
  path: 'transactions',
  loadChildren: () => import('./transactions/transactions.module').then(m => m.TransactionsModule),
  data: {
    title: 'TRANSACTIONS'
  }
}, {
  path: 'accounts',
  loadChildren: () => import('./accounts/accounts.module').then(m => m.AccountsModule)
}, {
  path: 'users',
  loadChildren: () => import('./users/users.module').then(m => m.UsersModule)
},
{ path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class FeatureRoutingModule { }
