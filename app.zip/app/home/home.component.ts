import { Component, OnInit, AfterViewInit, HostListener } from '@angular/core';
import { AppTitleService } from '../core/services/app-title.service';
import { Router, Route } from '@angular/router';

@Component({
  selector: 'pms-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewInit {
  title: string;
  focused = false;
  menuItems;
  constructor(
    private appTitleService: AppTitleService, private router: Router) { }

  ngOnInit() {
    this.appTitleService.titleBehaviorSubject.subscribe(title => {
      this.title = title;
    });
    console.log(this.router);
    const getAllPaths = (config: Route[]) => {
      config.forEach((route: Route) => {
        console.log(route.path);
        if (route.loadChildren) {
          getAllPaths(route._loadedConfig);
        }
      });
    };
    getAllPaths(this.router.config);
    this.menuItems = [
      {
        route: '/projects/create',
        labelHTML: 'Projects > <span class="text-success">Create</span>'
      },
      {
        route: '/projects/',
        labelHTML: 'Projects > <span class="text-primary">List</span>'
      }
    ];
  }

  @HostListener('window:keyup', ['$event'])
  keyEvent(event: KeyboardEvent) {
    console.log(event);
    console.log(event.ctrlKey, event.shiftKey, event.keyCode);
    console.log(event.ctrlKey && event.shiftKey && event.keyCode === KEY_CODE.P);
    if (event.ctrlKey && event.shiftKey && event.keyCode === KEY_CODE.P) {
      this.searchFocusEvent({});
    }
  }

  ngAfterViewInit(): void {
    const d = new Date();
    const year = d.getFullYear();
    document.getElementById('copy-year').innerHTML = year + '';
  }

  searchFocusEvent($event) {
    console.log($event, this.focused);
    this.focused = true;
  }
  searchFocusOutEvent($event) {
    console.log($event, this.focused);
    this.focused = false;
  }

}

export enum KEY_CODE {
  CTRL = 17,
  SHIFT = 16,
  P = 80
}
