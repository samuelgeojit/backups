import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SnackbarService {

  constructor() { }
  showSnackbar(message: string, action?: string) {
  }
}
