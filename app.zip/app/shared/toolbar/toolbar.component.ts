import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'pms-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss']
})
export class ToolbarComponent implements OnInit {
  mobileQuery: MediaQueryList;

  @Input()
  title: string;

  @Output()
  drawerToggleBtnClicked = new EventEmitter();

  constructor() { }

  ngOnInit(): void {

  }

  onDrawerToggleBtnClicked(): void {
    this.drawerToggleBtnClicked.emit();
  }
}
