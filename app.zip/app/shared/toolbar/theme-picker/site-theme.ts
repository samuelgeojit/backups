export interface SiteTheme {
  primaryColur: string;
  accentColur: string;
  href: string;
  isDark: boolean;
  isDefault?: boolean;
}
