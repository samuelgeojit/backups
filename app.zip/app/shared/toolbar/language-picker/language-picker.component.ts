import {Component, OnInit} from '@angular/core';
import {SiteLanguage} from './site-language';
import {LanguageStorageService} from './language-storage/language-storage.service';

@Component({
  selector: 'pms-language-picker',
  templateUrl: './language-picker.component.html',
  styleUrls: ['./language-picker.component.scss']
})
export class LanguagePickerComponent implements OnInit {

  siteLanguages: SiteLanguage[];

  constructor(private  languageStorageService: LanguageStorageService) {
    this.siteLanguages = languageStorageService.getLanguages();
  }

  ngOnInit() {

  }

  changeLanguage(language: SiteLanguage) {
    this.languageStorageService.storeLanguage(language);
  }
}
