export interface SiteLanguage {
  languageKey: string;
  language: string;
}
