import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AsyncOperationComponent } from './async-operation/async-operation.component';
import { LanguagePickerComponent } from './toolbar/language-picker/language-picker.component';
import { FullScreenTooglerComponent } from './toolbar/full-screen-toogler/full-screen-toogler.component';
import { ProfileMenuComponent } from './toolbar/profile-menu/profile-menu.component';
import { ThemePickerComponent } from './toolbar/theme-picker/theme-picker.component';
import { StyleManagerService } from './toolbar/theme-picker/style-manager/style-manager.service';
import { ThemeStorageService } from './toolbar/theme-picker/theme-storage/theme-storage.service';
import { DeleteConfirmDialogComponent } from './delete-confirm-dialog/delete-confirm-dialog.component';
import { ToolbarComponent } from './toolbar/toolbar.component';
@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  exports: [
    PageNotFoundComponent,
    ToolbarComponent,
    AsyncOperationComponent,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [StyleManagerService, ThemeStorageService],
  declarations: [
    PageNotFoundComponent,
    AsyncOperationComponent,
    ThemePickerComponent,
    LanguagePickerComponent,
    FullScreenTooglerComponent,
    ProfileMenuComponent,
    DeleteConfirmDialogComponent,
    ToolbarComponent,
  ]
})
export class SharedModule { }
