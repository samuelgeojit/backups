import { AppPage } from './app.po';

describe('RIPS App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display title for the page', () => {
    page.navigateTo();
    expect(page.getText()).toEqual('RIPS DEMO APP');
  });
});
