import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { Subject } from 'rxjs/Subject';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  private _onDestroy = new Subject<void>();

  private title = 'RIPS DEMO APP';

  private foods = [
    { value: 'steak', key: 'Steak' },
    { value: 'pizza', key: 'Pizza' },
    { value: 'tacos', key: 'Tacos' }
  ];
  private customSelectValue;
  private customSelectFormValue;
  private favoriteFoodFilter: FormControl = new FormControl();
  private customSelect: FormControl = new FormControl();

  private filteredFoods: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  ngOnInit() {
    this.filteredFoods.next(this.foods.slice());
    this.favoriteFoodFilter.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterFoods();
      });
    this.customSelect.valueChanges
    .pipe(takeUntil(this._onDestroy))
    .subscribe(() => {
      console.log('custom select value is changed');
      console.log(this.customSelect);
    });
    this.customSelectValue = this.foods[1].value;
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  private filterFoods() {
    if (!this.foods) {
      return;
    }
    let search = this.favoriteFoodFilter.value;
    if (!search) {
      this.filteredFoods.next(this.foods.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredFoods.next(
      this.foods.filter(food => food.key.toLowerCase().indexOf(search) > -1)
    );
  }

  onSubmit(value) {
    this.customSelectFormValue = JSON.stringify(value);
  }
}
