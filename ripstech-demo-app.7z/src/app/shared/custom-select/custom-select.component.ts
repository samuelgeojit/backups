import { Subject } from 'rxjs/Subject';
import { takeUntil } from 'rxjs/operators';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import {
  Component,
  OnInit,
  ElementRef,
  forwardRef,
  ViewChild,
  EventEmitter,
  Input,
  Output,
  OnDestroy,
  Optional,
  Inject
} from '@angular/core';

import {
  NG_VALUE_ACCESSOR,
  NG_VALIDATORS,
  ControlValueAccessor,
  FormControl,
  NgModel,
  NG_ASYNC_VALIDATORS
} from '@angular/forms';
import { CdkConnectedOverlay } from '@angular/cdk/overlay';
import { CdkOverlayOrigin } from '@angular/cdk/overlay';
import { ElementBase } from '../custom-element/element-base';

interface CustomSelectOption {
  key: string;
  value: string;
}

@Component({
  selector: 'app-custom-select',
  templateUrl: './custom-select.component.html',
  styleUrls: ['./custom-select.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: CustomSelectComponent,
    multi: true,
  }],
})
export class CustomSelectComponent extends ElementBase<string> implements OnInit, OnDestroy {

  @ViewChild(NgModel) model: NgModel;

  private _onDestroy = new Subject<void>();
  private _selectPlaceHolder: any = '';
  private _selectValue: any = '';

  /**
  * The method set in registerOnChange, it is just a placeholder for a method that takes one parameter,
  * We use it to emit changes back to the form
  */
  private _onTouchedCallback: () => {};
  private _onChangeCallback: (_: any) => {};
  private _validationError;

  /** Whether or not the overlay panel is open. */
  private _panelOpen = false;

  /**
   * This position config ensures that the top "start" corner of the overlay
   * is aligned with with the top "start" of the origin by default (overlapping
   * the trigger completely). If the panel cannot fit below the trigger, it
   * will fall back to a position above the trigger.
   */
  _positions = [
    {
      originX: 'start',
      originY: 'top',
      overlayX: 'start',
      overlayY: 'top',
    },
    {
      originX: 'start',
      originY: 'bottom',
      overlayX: 'start',
      overlayY: 'bottom',
    },
  ];


  @ViewChild(CdkConnectedOverlay) formSelectFilterContainer: CdkConnectedOverlay;
  @ViewChild(CdkOverlayOrigin) selectLabelContainer: CdkOverlayOrigin;

  @Input()
  // TODO: Implement Placeholder
  placeholder = '';
  @Input()
  filterPlaceholder = '';
  @Input()
  options: CustomSelectOption[];
  // TODO: Implement Disabled.
  @Input()
  disabled = '';
  @Input()
  filteredOptions: ReplaySubject<CustomSelectOption[]> = new ReplaySubject<CustomSelectOption[]>(1);
  @Output()
  filterValueChanged: EventEmitter<string>;
  @Output()
  valueChanged: EventEmitter<string>;

  private filterInput: FormControl = new FormControl();

  @ViewChild('trigger') trigger: ElementRef;
  private _selectLabelContainerRect: ClientRect;

  constructor(elementRef: ElementRef, @Optional() @Inject(NG_VALIDATORS) validators: Array<any>,
    @Optional() @Inject(NG_ASYNC_VALIDATORS) asyncValidators: Array<any>) {
    super(validators, asyncValidators);
  }

  ngOnInit() {
    this.filteredOptions.next(this.options.slice());
    this.filterInput.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterOptions();
      });
  }

  ngOnDestroy(): void {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  filterOptions() {
    if (!this.options) {
      return;
    }
    let search = this.filterInput.value;
    if (!search) {
      this.filteredOptions.next(this.options.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredOptions.next(
      this.options.filter(option => option.key.toLowerCase().indexOf(search) > -1)
    );
  }

  get panelOpen(): boolean {
    return this._panelOpen;
  }

  /** Toggles the overlay panel open or closed. */
  toggle(): void {
    this.panelOpen ? this.close() : this.open();
  }

  /** Opens the overlay panel. */
  open(): void {
    if (this.disabled || !this.options || !this.options.length) {
      return;
    }
    this._selectLabelContainerRect = this.trigger.nativeElement.getBoundingClientRect();
    this._panelOpen = true;
  }

  /** Closes the overlay panel and focuses the host element. */
  close(): void {
    if (this._panelOpen) {
      this._panelOpen = false;
    }
  }

  selectOption(option: CustomSelectOption) {
    this.writeValue(option.value);
    this.close();
  }
}
