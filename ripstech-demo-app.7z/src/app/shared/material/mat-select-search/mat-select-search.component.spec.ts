import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatSelectSearchComponent } from './mat-select-search.component';
import { CUSTOM_ELEMENTS_SCHEMA, Component, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule, MatButtonModule, MatInputModule, MatIconModule, MatSelect } from '@angular/material';
import { Subject } from 'rxjs/Subject';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { takeUntil, take } from 'rxjs/operators';

@Component({
  selector: 'app-mat-select-search-test',
  template: `
  <mat-form-field>
    <mat-select placeholder="Favorite food">
        <app-mat-select-search [formControl]="favoriteFoodFilter" [placeholderLabel]="'Enter some favorites'" [noEntriesFoundLabel]="'Food not found'"></app-mat-select-search>
        <mat-option *ngFor="let food of filteredFoods | async" [value]="food.value">
            {{ food.viewValue }}
        </mat-option>
    </mat-select>
  </mat-form-field>
  `,
})
export class MatSelectSearchTestComponent implements OnInit, OnDestroy {

  @ViewChild(MatSelect) matSelect: MatSelect;
  @ViewChild(MatSelectSearchComponent) matSelectSearch: MatSelectSearchComponent;

  private _onDestroy = new Subject<void>();

  private foods = [
    { value: 'steak', viewValue: 'Steak' },
    { value: 'pizza', viewValue: 'Pizza' },
    { value: 'tacos', viewValue: 'Tacos' }
  ];
  favoriteFoodFilter: FormControl = new FormControl();
  filteredFoods: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  ngOnInit() {
    this.filteredFoods.next(this.foods.slice());
    this.favoriteFoodFilter.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterFoods();
      });
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  private filterFoods() {
    if (!this.foods) {
      return;
    }
    let search = this.favoriteFoodFilter.value;
    if (!search) {
      this.filteredFoods.next(this.foods.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredFoods.next(
      this.foods.filter(food => food.viewValue.toLowerCase().indexOf(search) > -1)
    );
  }
}
describe('MatSelectSearchComponent', () => {

  let component: MatSelectSearchTestComponent;
  let fixture: ComponentFixture<MatSelectSearchTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MatSelectSearchComponent, MatSelectSearchTestComponent],
      imports: [
        CommonModule,
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatSelectModule,
        MatButtonModule,
        MatInputModule,
        MatIconModule
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatSelectSearchTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show a search field and focus it when opening the select', (done) => {

    component.filteredFoods
      .pipe(take(1))
      .subscribe(() => {
        // when the filtered banks are initialized
        fixture.detectChanges();

        component.matSelect.open();
        fixture.detectChanges();

        component.matSelect.openedChange
          .pipe(take(1))
          .subscribe((opened) => {
            expect(opened).toBe(true);
            const searchField = document.querySelector('.cdk-overlay-pane-select-search .mat-select-search-inner .mat-select-search-input');
            const searchInner = document.querySelector('.cdk-overlay-pane-select-search .mat-select-search-inner');
            expect(searchInner).toBeTruthy();
            expect(searchField).toBeTruthy();
            // check focus
            expect(searchField).toBe(document.activeElement);

            const optionElements = document.querySelectorAll('.cdk-overlay-pane-select-search mat-option');
            expect(component.matSelect.options.length).toBe(3);
            expect(optionElements.length).toBe(3);

            done();
          });

      });

  });

  it('should filter the options available and hightlight the first option in the list, filter the options by input "steak" and reset the list', (done) => {

    component.filteredFoods
      .pipe(take(1))
      .subscribe(() => {
        // when the filtered banks are initialized
        fixture.detectChanges();

        component.matSelect.open();
        fixture.detectChanges();

        component.matSelect.openedChange
          .pipe(take(1))
          .subscribe((opened) => {
            expect(opened).toBe(true);
            const searchField = document.querySelector('.cdk-overlay-pane-select-search .mat-select-search-inner .mat-select-search-input');
            expect(searchField).toBeTruthy();

            expect(component.matSelect.options.length).toBe(3);

            // search for "steak"
            component.matSelectSearch.onInputChange('steak');
            fixture.detectChanges();

            expect(component.favoriteFoodFilter.value).toBe('steak');
            expect(component.matSelect.panelOpen).toBe(true);

            component.filteredFoods
              .pipe(take(1))
              .subscribe(() => {
                fixture.detectChanges();

                setTimeout(() => {
                  expect(component.matSelect.options.length).toBe(1);
                  expect(component.matSelect.options.first.value).toBe('steak');
                  expect(component.matSelect.options.first.active).toBe(true, 'first active');

                  component.matSelectSearch._reset(true);
                  fixture.detectChanges();

                  // check focus
                  expect(searchField).toBe(document.activeElement);
                  expect(component.matSelect.panelOpen).toBe(true);

                  component.filteredFoods
                    .pipe(take(1))
                    .subscribe(() => {
                      fixture.detectChanges();
                      expect(component.matSelect.options.length).toBe(3);

                      done();
                    });
                });

              });

          });

      });

  });
});
