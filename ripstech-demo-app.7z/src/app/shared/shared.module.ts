import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './material/material.module';
import { CustomSelectModule } from './custom-select/custom-select.module';

@NgModule({
  exports: [
    MaterialModule,
    CustomSelectModule
  ],
  imports: [
    CommonModule,
    MaterialModule,
    CustomSelectModule
  ],
  declarations: []
})
export class SharedModule { }
