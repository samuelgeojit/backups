import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs/Rx';
import { User } from '../models/user';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { JwtService } from './jwt.service';
import { ApiService } from '../../shared/services/api.service';
@Injectable()
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User>(new User());
  public currentUser = this.currentUserSubject.asObservable().distinctUntilChanged();

  private isAuthenticatedSubject = new ReplaySubject<boolean>(1);
  public isAuthenticatedObservable = this.isAuthenticatedSubject.asObservable();

  constructor(private apiService: ApiService,
    private jwtService: JwtService) {
    /**
     *
     * Verify JWT in localstorage with server & load user's info.
     * This runs once on application startup.
     * This is to prevent loging out when user hits browser reload or refresh.
     */
  }
  populate() {
    // If JWT detected, attempt to get & store user's info
    if (this.jwtService.getToken()) {
      this.apiService.get('/user')
        .subscribe(
        data => this.setAuth(data.user),
        err => this.purgeAuth()
        );
    } else {
      // Remove any potential remnants of previous auth states
      this.purgeAuth();
    }
  }
  /**
   *
   * @returns {Observable<T>}
   */
  isAuthenticated(): Observable<boolean> {
    return this.isAuthenticatedObservable;
  }

  /**
   *  Login the user then tell all the subscribers about the new status
   */
  private setAuth(user: User) {
    // Save JWT sent from server in localstorage
    this.jwtService.saveToken(user.token);
    // Set current user data into observable
    this.currentUserSubject.next(user);
    // Set isAuthenticated to true
    this.isAuthenticatedSubject.next(true);
  }

  attemptAuth(username: string, password: string): Observable<User> {
    return this.apiService.post('/api/authenticate', { username: username, password: password })
      .map(
      data => {
        this.setAuth(data.user);
        return data;
      }
      );
  }

  /**
   * Log out the user then tell all the subscribers about the new status
   */
  private purgeAuth() {
    // Remove JWT from localstorage
    this.jwtService.destroyToken();
    // Set current user to an empty object
    this.currentUserSubject.next(new User());
    // Set auth status to false
    this.isAuthenticatedSubject.next(false);
  }

  getCurrentUser(): User {
    return this.currentUserSubject.getValue();
  }
}
