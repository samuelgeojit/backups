import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { User } from '../../models/user';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  model: User;
  loading = false;
  returnUrl: string;
  loginForm: FormGroup;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService) {
  }

  ngOnInit() {
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    if (this.userService.isLoggedIn()) {
      this.router.navigateByUrl(this.returnUrl);
    }
    this.model = new User;
  }

  login() {
    this.loading = true;
    this.userService.attemptAuth(this.model.username, this.model.password)
      .subscribe(
      data => {
        // login successful so redirect to return url
        this.router.navigateByUrl(this.returnUrl);
      },
      error => {
        // login failed so display error
        this.loading = false;
      });
  }

}
