export class User {
    username:string;
    password:string;
    name: string;
    email: string;
    token: string;
    bio: string;
    image: string;
}
